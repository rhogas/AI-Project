TEAM MEMBERS:
- Sabela Rubert Docampo (NIA: 100523102)
- Alejandro Carrascosa Gordo (NIA: 100523032)
- Roberto Hogas Goras (NIA: 100523139)


To test the program, enter the following command in the terminal inside the files folder:

python3 main.py <scenario> <tolerance>

Where:
- You can change 'python3' to 'python', depending on your Python version.
- <scenario> must have the same name as one of the scenarios in the 'scenarios.json' file. Example: "scenario_5"
- <tolerance> must be between epsilon (0.0001) and 1. The higher the tolerance, the greater the chance of finding a solution.